create view stu_order_list as
select `boot_tsm`.`order_stu`.`o_stu_id`  AS `o_stu_id`,
       `boot_tsm`.`order_stu`.`stu_id`    AS `stu_id`,
       `boot_tsm`.`course`.`semester`     AS `semester`,
       `boot_tsm`.`apply`.`isbn`          AS `isbn`,
       `boot_tsm`.`apply`.`title`         AS `title`,
       `boot_tsm`.`coursedtl`.`cdtl_name` AS `cdtl_name`,
       `boot_tsm`.`order_stu`.`status`    AS `status`
from (((`boot_tsm`.`order_stu` left join `boot_tsm`.`apply` on ((`boot_tsm`.`order_stu`.`apply_id` = `boot_tsm`.`apply`.`apply_id`))) join `boot_tsm`.`coursedtl`)
         join `boot_tsm`.`course` on (((`boot_tsm`.`coursedtl`.`cdtl_id` = `boot_tsm`.`course`.`cdtl_id`) and
                                       (`boot_tsm`.`apply`.`cors_id` = `boot_tsm`.`course`.`cors_id`))));

-- comment on column stu_order_list.o_stu_id not supported: 自增主键

-- comment on column stu_order_list.stu_id not supported: 学号-外键

-- comment on column stu_order_list.semester not supported: 学期

-- comment on column stu_order_list.isbn not supported: ISBN码

-- comment on column stu_order_list.title not supported: 教材名称

-- comment on column stu_order_list.cdtl_name not supported: 课程名称

-- comment on column stu_order_list.status not supported: 0:未领取 1:已领取

