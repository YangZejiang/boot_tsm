create view stu_book_list as
select `boot_tsm`.`schedule_stu`.`stu_id` AS `stu_id`,
       `boot_tsm`.`coursedtl`.`cdtl_name` AS `cdtl_name`,
       `boot_tsm`.`course`.`semester`     AS `semester`,
       `boot_tsm`.`apply`.`apply_id`      AS `apply_id`,
       `boot_tsm`.`teacher`.`tch_name`    AS `tch_name`,
       `boot_tsm`.`apply`.`title`         AS `title`,
       `boot_tsm`.`apply`.`isbn`          AS `isbn`,
       `boot_tsm`.`coursedtl`.`nature`    AS `nature`
from ((((`boot_tsm`.`schedule_stu` join `boot_tsm`.`course` on ((`boot_tsm`.`schedule_stu`.`cors_id` = `boot_tsm`.`course`.`cors_id`))) join `boot_tsm`.`coursedtl` on ((`boot_tsm`.`course`.`cdtl_id` = `boot_tsm`.`coursedtl`.`cdtl_id`))) join `boot_tsm`.`apply` on ((`boot_tsm`.`course`.`cors_id` = `boot_tsm`.`apply`.`cors_id`)))
         join `boot_tsm`.`teacher` on ((`boot_tsm`.`course`.`tch_id` = `boot_tsm`.`teacher`.`tch_id`)));

-- comment on column stu_book_list.stu_id not supported: 学号-外键

-- comment on column stu_book_list.cdtl_name not supported: 课程名称

-- comment on column stu_book_list.semester not supported: 学期

-- comment on column stu_book_list.apply_id not supported: 自增主键

-- comment on column stu_book_list.tch_name not supported: 教师姓名

-- comment on column stu_book_list.title not supported: 教材名称

-- comment on column stu_book_list.isbn not supported: ISBN码

-- comment on column stu_book_list.nature not supported: 课程性质：公共选修

