create view tch_course_list as
select `boot_tsm`.`course`.`cors_id`        AS `cors_id`,
       `boot_tsm`.`course`.`semester`       AS `semester`,
       `boot_tsm`.`course`.`tch_id`         AS `tch_id`,
       `boot_tsm`.`course`.`cdtl_id`        AS `cdtl_id`,
       `boot_tsm`.`course`.`status`         AS `status`,
       `boot_tsm`.`coursedtl`.`cdtl_name`   AS `cdtl_name`,
       `boot_tsm`.`coursedtl`.`credit`      AS `credit`,
       `boot_tsm`.`coursedtl`.`credit_hour` AS `credit_hour`,
       `boot_tsm`.`coursedtl`.`nature`      AS `nature`,
       `boot_tsm`.`coursedtl`.`campus_code` AS `campus_code`,
       `boot_tsm`.`coursedtl`.`college`     AS `college`,
       `boot_tsm`.`coursedtl`.`attribution` AS `attribution`
from (`boot_tsm`.`course`
         left join `boot_tsm`.`coursedtl` on ((`boot_tsm`.`course`.`cdtl_id` = `boot_tsm`.`coursedtl`.`cdtl_id`)));

-- comment on column tch_course_list.cors_id not supported: 自增主键

-- comment on column tch_course_list.semester not supported: 学期

-- comment on column tch_course_list.tch_id not supported: 教工号-外键

-- comment on column tch_course_list.cdtl_id not supported: 课程代码-外键

-- comment on column tch_course_list.status not supported: 1:开课 0：未开

-- comment on column tch_course_list.cdtl_name not supported: 课程名称

-- comment on column tch_course_list.credit not supported: 学分：3.0

-- comment on column tch_course_list.credit_hour not supported: 学时：96

-- comment on column tch_course_list.nature not supported: 课程性质：公共选修

-- comment on column tch_course_list.campus_code not supported: 校区代码：青山湖

-- comment on column tch_course_list.college not supported: 开课学院：计算机系

-- comment on column tch_course_list.attribution not supported: 课程归属：校公选课

