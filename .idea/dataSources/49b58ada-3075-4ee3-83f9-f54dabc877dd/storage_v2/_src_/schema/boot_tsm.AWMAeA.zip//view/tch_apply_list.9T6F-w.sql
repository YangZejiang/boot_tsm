create view tch_apply_list as
select `boot_tsm`.`apply`.`apply_id`      AS `apply_id`,
       `boot_tsm`.`apply`.`isbn`          AS `isbn`,
       `boot_tsm`.`apply`.`title`         AS `title`,
       `boot_tsm`.`course`.`semester`     AS `semester`,
       `boot_tsm`.`course`.`tch_id`       AS `tch_id`,
       `boot_tsm`.`course`.`cdtl_id`      AS `cdtl_id`,
       `boot_tsm`.`coursedtl`.`cdtl_name` AS `cdtl_name`
from ((`boot_tsm`.`apply` left join `boot_tsm`.`course` on ((`boot_tsm`.`apply`.`cors_id` = `boot_tsm`.`course`.`cors_id`)))
         join `boot_tsm`.`coursedtl` on ((`boot_tsm`.`course`.`cdtl_id` = `boot_tsm`.`coursedtl`.`cdtl_id`)));

-- comment on column tch_apply_list.apply_id not supported: 自增主键

-- comment on column tch_apply_list.isbn not supported: ISBN码

-- comment on column tch_apply_list.title not supported: 教材名称

-- comment on column tch_apply_list.semester not supported: 学期

-- comment on column tch_apply_list.tch_id not supported: 教工号-外键

-- comment on column tch_apply_list.cdtl_id not supported: 课程代码-外键

-- comment on column tch_apply_list.cdtl_name not supported: 课程名称

